const Service = [
  {
    image: "/floor.jpeg",
    Name: "Office Clean",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque nisl purus, blandit id tincidunt sit amet, vulputate id sem. ",
  },
  {
    image: "/window.jpeg",
    Name: "School Clean",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque nisl purus, blandit id tincidunt sit amet, vulputate id sem. ",
  },
  {
    image: "/surface.jpeg",
    Name: "Contract clean",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque nisl purus, blandit id tincidunt sit amet, vulputate id sem. ",
  },
];

export default Service;
